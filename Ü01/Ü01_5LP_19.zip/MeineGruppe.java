public class MeineGruppe {
    public static void main(String[] args) {
    //Passen Sie die folgenden Zeilen entsprechend Ihrer Gruppe an
    int anzahlMitglieder = 4;
    int gruppenNummer = 19;
    String name1 = "Hasan Barut";
    String name2 = "Nora Fritz";
    String name3 = "Melina Hoffmann";
    String name4 = "Monika mayer";
    //...
    //Ausgabe
    System.out.println("Zur OOP-Gruppe " + gruppenNummer + " gehören:");
    System.out.println("1. " + name1);
    System.out.println("2. " + name2);
    System.out.println("3. " + name3);
    System.out.println("4. " + name4);
    //...
    System.out.println("Anzahl Mitglieder: " + anzahlMitglieder);
    }
    }